export class LoginUser {
    username: string;
    password: string
}