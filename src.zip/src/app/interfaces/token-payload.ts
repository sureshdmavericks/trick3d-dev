export class TokenPayload {
    username:string
    email:string
    role:string
}