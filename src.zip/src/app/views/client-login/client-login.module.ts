import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientLoginRoutingModule } from './client-login-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ClientLoginRoutingModule
  ]
})
export class ClientLoginModule { }
