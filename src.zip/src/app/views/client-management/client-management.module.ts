import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientManagementRoutingModule } from './client-management-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ClientManagementRoutingModule
  ]
})
export class ClientManagementModule { }
